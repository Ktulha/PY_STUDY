class Note:
    id: str
    title: str
    text: str